#include <ros/ros.h>
#include <tf/transform_broadcaster.h>

//Transform from odometry to map
int main(int argc, char** argv){
  ros::init(argc, argv, "drone_odom_tf_publisher");
  ros::NodeHandle n;

  ros::Rate r(100);

  tf::TransformBroadcaster broadcaster;

  while(n.ok()){
    broadcaster.sendTransform(
      tf::StampedTransform(
	//TODO replace with input from QTS
	//passing quaternion saying "don't turn", a vector for offset in metres, a timestamp, parent and child frame names
        tf::Transform(tf::Quaternion(0, 0, 0, 1), tf::Vector3(0, 0, 0)),
        ros::Time::now(),"map", "drone_odom"));
    r.sleep();
  }
}
