#include <ros/ros.h>
#include <geometry_msgs/PointStamped.h>
#include <tf/transform_listener.h>

void transformPoint(const tf::TransformListener& listener){
  //create a point in the map frame to transform to the world frame
  geometry_msgs::PointStamped map_point;
  map_point.header.frame_id = "map";

  //use the most recent transform available
  map_point.header.stamp = ros::Time();

  //just an arbitrary point in space
	//TODO replace this with QTS input?
  map_point.point.x = 1.0;
  map_point.point.y = 1.0;
  map_point.point.z = 1.0;

  try{
    geometry_msgs::PointStamped world_point;
    listener.transformPoint("world", map_point, world_point);


    ROS_INFO("map: (%.2f, %.2f. %.2f) -----> world: (%.2f, %.2f, %.2f) at time %.2f",
        map_point.point.x, map_point.point.y, map_point.point.z,
        world_point.point.x, world_point.point.y, world_point.point.z, world_point.header.stamp.toSec());
  }
  catch(tf::TransformException& ex){
    ROS_ERROR("Received an exception trying to transform a point from \"map\" to \"world\": %s", ex.what());
  }
}

int main(int argc, char** argv){
  ros::init(argc, argv, "drone_tf_listener");
  ros::NodeHandle n;

  tf::TransformListener listener(ros::Duration(10));

  //transform a point once every second
  ros::Timer timer = n.createTimer(ros::Duration(1.0), boost::bind(&transformPoint, boost::ref(listener)));

  ros::spin();

}
