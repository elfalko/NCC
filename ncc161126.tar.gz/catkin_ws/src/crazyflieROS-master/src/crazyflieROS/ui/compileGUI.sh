pyuic4 driverGUI.ui > driverGUI.py
pyuic4 trackerGUI.ui > trackerGUI.py
pyuic4 masterDialog.ui > masterDialog.py
