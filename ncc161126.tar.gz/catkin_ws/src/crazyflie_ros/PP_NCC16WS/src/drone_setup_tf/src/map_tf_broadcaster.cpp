#include <ros/ros.h>
#include <tf/transform_broadcaster.h>

//Transform from map to world
int main(int argc, char** argv){
  ros::init(argc, argv, "map_tf_publisher");
  ros::NodeHandle n;

  ros::Rate r(100);

  tf::TransformBroadcaster broadcaster;

  while(n.ok()){
    broadcaster.sendTransform(
      tf::StampedTransform(
	//as the map (representing the Qualisys Tracking System input later on) can be calibrated to be the same as the world, all transformation is set to zero
	//passing quaternion saying "don't turn", a vector for offset in metres, a timestamp, parent and child frame names
        tf::Transform(tf::Quaternion(0, 0, 0, 1), tf::Vector3(0, 0, 0)),
        ros::Time::now(),"world", "map"));
    r.sleep();
  }
}
